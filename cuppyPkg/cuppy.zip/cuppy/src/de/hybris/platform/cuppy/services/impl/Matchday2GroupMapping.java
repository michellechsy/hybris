/**
 * 
 */
package de.hybris.platform.cuppy.services.impl;

/**
 * @author andreas.thaler
 * 
 */
public class Matchday2GroupMapping
{
	private int matchday;
	private String group;

	public int getMatchday()
	{
		return matchday;
	}

	public void setMatchday(final int matchday)
	{
		this.matchday = matchday;
	}

	public String getGroup()
	{
		return group;
	}

	public void setGroup(final String group)
	{
		this.group = group;
	}
}
